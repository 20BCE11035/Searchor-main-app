---
name: Feature request
about: "\U0001F680 Suggest an feature!"
title: ''
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe if so, otherwise leave this blank..**

**Describe the feature**
<-- A clear and concise description of the feature. What will it do, what will it affect, etc. -->

**Provide any alternatives to the feature you've considered**
Any other alternatives to the feature request you are asking for if we decide not to go with your feature request?

**Additional information**
<-- If you have anything additional to say, you can say it here. Otherwise you can leave this blank. -->
